<?php $__env->startSection('content'); ?>

    <form method="POST" action="<?php echo e(route("showPlayerList")); ?>">
        <?php echo csrf_field(); ?>
            <select name="roleToFind">
                        <option>Show all</option> <!--shows this first non alphabetised-->
                <?php if(isset($players)): ?>
                    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!--displays all roles to menu-->
                        <option value="<?php echo e($player->role); ?>"><?php echo e($player->role); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <br /><br /><input type = "submit" value = "Find player"> <input type = "reset" value = "Reset search">
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phil/Sites/Cricket/resources/views/menu.blade.php ENDPATH**/ ?>