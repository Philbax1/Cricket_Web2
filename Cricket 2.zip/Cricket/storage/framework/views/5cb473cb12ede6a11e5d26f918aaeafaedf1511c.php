<!--Page that displays singular player, user has searched for-->

<!--references template2-->

<?php $__env->startSection('content1'); ?><!--displays player image-->
    <img src="<?php echo e(asset("images/$player->image")); ?>" width="80%" height="80%">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name'); ?> <!--displays player name-->
    <h3><?php echo e($player->playerName); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?><!--displays player information-->
    <p32>Role: </p32>  <p3> <?php echo e($player->role); ?> </p3> <br />
    <p32>Batting: </p32> <p3> <?php echo e($player->batting); ?> </p3> <br />
    <p32>Bowling: </p32> <p3> <?php echo e($player->bowling); ?> </p3> <br />
    <p32>OdiRuns: </p32> <p3> <?php echo e($player->odiRuns); ?> </p3> <br />
    <p32>Country: </p32> <p3> <?php echo e($player->country->name); ?> </p3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('back'); ?>
    <hr width="80%"><br /> <p3> <a href="<?php echo e(route("chooseRole")); ?>">Back to search </p3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phil/Sites/cricket/resources/views/viewPlayer.blade.php ENDPATH**/ ?>