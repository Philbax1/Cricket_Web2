<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!--prints all players that have been searched for-->
        <a href = "<?php echo e(route("showIndividualPlayer", $player-> id)); ?>"> <?php echo e($player->playerName); ?> </a> <br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('back'); ?>
    <hr width="80%"><br /> <p3> <a href="<?php echo e(route("chooseRole")); ?>">Back to search </p3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/phil/Sites/cricket/resources/views/playerList.blade.php ENDPATH**/ ?>