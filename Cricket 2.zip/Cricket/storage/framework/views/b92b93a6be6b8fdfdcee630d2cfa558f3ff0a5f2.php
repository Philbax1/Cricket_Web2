<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="<?php echo asset('css/css.css')?>" type="text/css">

        <title>Cricket_playerFinder</title>

    </head>
    <body>

<div class="bg">
    <div class="container">
                <div class="header">
                    <?php echo $__env->yieldContent('name'); ?>
                </div>

        <div class="responsive">
            <div class="twocolumn">
                <?php echo $__env->yieldContent('content1'); ?>
            </div>

            <div class="twocolumn">
                <?php echo $__env->yieldContent('content2'); ?>
            </div>

            <div class="onecolumn">
                    <?php echo $__env->yieldContent('back'); ?>
            </div>
        </div>
    </div>
</div>

    </body>
</html>
<?php /**PATH /Users/phil/Sites/cricket/resources/views/template2.blade.php ENDPATH**/ ?>