<!--Page that displays singular player, user has searched for-->

@extends('template2')<!--references template2-->

@section('content1')<!--displays player image-->
    <img src="{{asset("images/$player->image")}}" width="80%" height="80%">
@endsection

@section('name') <!--displays player name-->
    <h3>{{$player->playerName}}</h3>
@endsection

@section('content2')<!--displays player information-->
    <p32>Role: </p32>  <p3> {{$player->role}} </p3> <br />
    <p32>Batting: </p32> <p3> {{$player->batting}} </p3> <br />
    <p32>Bowling: </p32> <p3> {{$player->bowling}} </p3> <br />
    <p32>OdiRuns: </p32> <p3> {{$player->odiRuns}} </p3> <br />
    <p32>Country: </p32> <p3> {{$player->country->name}} </p3>
@endsection

@section('back')
    <hr width="80%"><br /> <p3> <a href="{{route("chooseRole")}}">Back to search </p3>
@endsection
