@extends('template')
@section('content')

    @foreach ($players as $player) <!--prints all players that have been searched for-->
        <a href = "{{route("showIndividualPlayer", $player-> id)}}"> {{$player->playerName}} </a> <br />
    @endforeach

@endsection

@section('back')
    <hr width="80%"><br /> <p3> <a href="{{route("chooseRole")}}">Back to search </p3>
@endsection
