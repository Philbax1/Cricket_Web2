@extends('template')

@section('content')

    <form method="POST" action="{{route("showPlayerList")}}">
        @csrf
            <select name="roleToFind">
                        <option>Show all</option> <!--shows this first non alphabetised-->
                @if(isset($players))
                    @foreach ($players as $player) <!--displays all roles to menu-->
                        <option value="{{$player->role}}">{{$player->role}}</option>
                    @endforeach
                @endif
            </select>
            <br /><br /><input type = "submit" value = "Find player"> <input type = "reset" value = "Reset search">
    </form>

@endsection
