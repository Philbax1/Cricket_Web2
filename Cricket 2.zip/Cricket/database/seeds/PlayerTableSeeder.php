<?php

use Illuminate\Database\Seeder;

class PlayerTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() //seeds content into database
    {
        DB::table('v2_players')->insert([
            ['id'=>'null','name'=>'Kane Williamson','age'=>'29','role'=>'Top-order batsman','batting'=>'Right-hand bat','bowling'=>'Right-arm offbreak','image'=>'williamson.jpg','odiRuns'=>'6132','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Trent Boult','age'=>'29','role'=>'Bowler','batting'=>'Right-hand bat','bowling'=>'Left-arm fast-medium','image'=>'boult.jpg','odiRuns'=>'154','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Tom Blundell','age'=>'28','role'=>'Wicketkeeper batsman','batting'=>'Right-hand bat','bowling'=>'Right-arm offbreak','image'=>'blundell.jpg','odiRuns'=>'0','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Colin de Grandhomme','age'=>'32','role'=>'Allrounder','batting'=>'Right-hand bat','bowling'=>'Right-arm fast-medium','image'=>'grandhomme.jpg','odiRuns'=>'633','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Lockie Ferguson','age'=>'27','role'=>'Bowler','batting'=>'Right-hand bat','bowling'=>'Right-arm fast','image'=>'ferguson.jpg','odiRuns'=>'62','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Martin Guptill','age'=>'32','role'=>'Opening batsman','batting'=>'Right-hand bat','bowling'=>'Right-arm offbreak','image'=>'guptil.jpg','odiRuns'=>'6626','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Matt Henry','age'=>'27','role'=>'Bowler','batting'=>'Right-hand bat','bowling'=>'Right-arm fast-medium','image'=>'henry.jpg','odiRuns'=>'211','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Tom Latham','age'=>'27','role'=>'Wicketkeeper batsman','batting'=>'Left-hand bat','bowling'=>'Right-arm medium','image'=>'latham.jpg','odiRuns'=>'2550','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Colin Munro','age'=>'32','role'=>'Middle-order batsman','batting'=>'Left-hand bat','bowling'=>'Right-arm medium-fast','image'=>'munro.jpg','odiRuns'=>'1271','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'James Neesham','age'=>'28','role'=>'Batting allrounder','batting'=>'Left-hand bat','bowling'=>'Right-arm medium','image'=>'neesham.jpg','odiRuns'=>'1247','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Henry Nicholls','age'=>'27','role'=>'Top-order batsman','batting'=>'Left-hand bat','bowling'=>'Right-arm offbreak','image'=>'nicholls.jpg','odiRuns'=>'1120','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Mitchell Santner','age'=>'27','role'=>'Bowling allrounder','batting'=>'Left-hand bat','bowling'=>'Slow left-arm orthodox','image'=>'santer.jpg','odiRuns'=>'898','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Ish Sodhi','age'=>'26','role'=>'Bowler','batting'=>'Right-hand bat','bowling'=>'Legbreak','image'=>'sodhi.jpg','odiRuns'=>'67','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Tim Southee','age'=>'30','role'=>'Bowler','batting'=>'Right-hand bat','bowling'=>'Right-arm medium-fast','image'=>'southee.jpg','odiRuns'=>'676','created_at'=>'null','updated_at'=>'null','country_id'=>'1'],
            ['id'=>'null','name'=>'Ross Taylor','age'=>'35','role'=>'Middle-order batsman','batting'=>'Right-hand bat','bowling'=>'Right-arm offbreak','image'=>'taylor.jpg','odiRuns'=>'8376','created_at'=>'null','updated_at'=>'null','country_id'=>'1']
        ]);
    }
}

/*
insert into v2_players values
(null,"Kane Williamson","29","Top-order batsman","Right-hand bat","Right-arm offbreak","williamson.jpg","6132",null,null,"1"),
(null,"Trent Boult","29","Bowler","Right-hand bat","Left-arm fast-medium","boult.jpg","154",null,null,"1"),
(null,"Tom Blundell","28","Wicketkeeper batsman","Right-hand bat","Right-arm offbreak","blundell.jpg","0",null,null,"1"),
(null,"Colin de Grandhomme","32","Allrounder","Right-hand bat","Right-arm fast-medium","grandhomme.jpg","633",null,null,"1"),
(null,"Lockie Ferguson","27","Bowler","Right-hand bat","Right-arm fast","ferguson.jpg","62",null,null,"1"),
(null,"Martin Guptill","32","Opening batsman","Right-hand bat","Right-arm offbreak","guptil.jpg","6626",null,null,"1"),
(null,"Matt Henry","27","Bowler","Right-hand bat","Right-arm fast-medium","henry.jpg","211",null,null,"1"),
(null,"Tom Latham","27","Wicketkeeper batsman","Left-hand bat","Right-arm medium","latham.jpg","2550",null,null,"1"),
(null,"Colin Munro","32","Middle-order batsman","Left-hand bat","Right-arm medium-fast","munro.jpg","1271",null,null,"1"),
(null,"James Neesham","28","Batting allrounder","Left-hand bat","Right-arm medium","neesham.jpg","1247",null,null,"1"),
(null,"Henry Nicholls","27","Top-order batsman","Left-hand bat","Right-arm offbreak","nicholls.jpg","1120",null,null,"1"),
(null,"Mitchell Santner","27","Bowling allrounder","Left-hand bat","Slow left-arm orthodox","santer.jpg","898",null,null,"1"),
(null,"Ish Sodhi","26","Bowler","Right-hand bat","Legbreak","sodhi.jpg","67",null,null,"1"),
(null,"Tim Southee","30","Bowler","Right-hand bat","Right-arm medium-fast","southee.jpg","676",null,null,"1"),
(null,"Ross Taylor","35","Middle-order batsman","Right-hand bat","Right-arm offbreak","taylor.jpg","8376",null,null,"1");
*/
