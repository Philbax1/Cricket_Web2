<?php

use Illuminate\Database\Seeder;

class CountryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() //seeds content into database
    {
        DB::table('v2_players')->insert([
            ['id'=>'null','name'=>'New Zealand','countryFlag'=>'null','created_at'=>'null','updated_at'=>'null']
            ]);
    }
}

/*
insert into v2_countries values
(null, "New Zealand","null",null ,null);
*/
