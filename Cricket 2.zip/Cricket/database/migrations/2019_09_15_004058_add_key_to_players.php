<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddKeyToPlayers extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() //adds keys to fields as didn't do correctly when created
    {
        Schema::table('v2_players', function ($table) {
            $table->integer('country_id')->unsigned()->nullable();
            $table->foreign('country_id')->references('id')->on('v2_countries');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('v2_players', function ($table) {
            $table->dropColumn('country_id');
        });
    }
}
