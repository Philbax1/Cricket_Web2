<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateV2PlayersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() //creates table field names for v2_players
    {
        Schema::create('v2_players', function (Blueprint $table) {
            $table->increments('id');
            $table->string('playerName',50);
            $table->decimal('age',10)->nullable();
            $table->string('role',50)->nullable();
            $table->string('batting',50)->nullable();
            $table->string('bowling',50)->nullable();
            $table->string('image',50)->nullable();
            $table->string('odiRuns',50)->nullable();
            //$table->integer('country_id')->unsigned()->nullable()->change();
            //$table->foreign('country_id')->references('id')->on('v2_countries')->change();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */

    public function down()
    {
        Schema::dropIfExists('v2_players');
    }
}
