<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class v2Country extends Model
{
    //


    public function players()  //creates relational join
    {
        return $this->hasMany('App\v2Player');
    }

}
