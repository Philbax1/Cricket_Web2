<?php

namespace App\Http\Controllers;

use App\v2Player;
use Illuminate\Http\Request;
use PhpParser\ErrorHandler\Collecting;

class MainController extends Controller
{

    function chooseRole(Request $request) {

        $players = v2Player::select('role')->distinct()->orderBy("role")->get(); //takes all info that is "role" orders alphabetically
        return view('menu')->with(['players'=>$players]); //return menu with info that was collated above
    }

    function showPlayerList(Request $request) {

        $r = $request->get('roleToFind');

        if ($r=="Show all") $players = v2Player::all(); //if user selects show all, show all of v2player
        else $players = v2Player::where('role',$r)->get();

        return view('playerList')->with(['players'=>$players]);//return playerList with info that was collated above

    }

    function showIndividualPlayer($playerID, Request $request) {

        $player = v2Player::find($playerID); //find player that has the id that was passes from user clicking on list
        return view('viewPlayer')->with(['player'=>$player]); //return viewPlayer with info that was collated above

    }

}
