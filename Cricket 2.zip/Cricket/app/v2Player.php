<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class v2Player extends Model
{
    //


    public function country()  //creates relational join
    {
        return $this->belongsTo('App\v2Country');
    }


}
